/*
			Sql Project Name: Shop management System 
			   Trainee Name:Mehedi Hasan Rabby
						Batch: PNTL-21
---------------------------------------------------------------------------------
Table of content :
             Section 01:Create a database.
			 Section 02:Created Appropriate Tables with column definition related to the project.
			 Section 03: Add check constraint on a table .
			 Section 04:Alter ,Drop ,Modify table and column.
			 Section 06:Create view and alter view.
			 Section 07:Create store procudure and alter store procudure.
			 Section 08:Create Function and alter function.
*/
			

/*							 Section 01   
						=> Create a Database 
*/

create database shop_management
on --primary
(
name='shop data',
filename='c:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\shop_data01.mdf',
size=20mb,
maxsize=100mb,
filegrowth=5%

)
log on--log file
(
name='shop log',
filename='c:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\shop_data02.ldf',
size=20mb,
maxsize=100mb,
filegrowth=2%
)
go

					         Section 02
				            Create table 
           ------------------------------------------
*/
Create table catagory
(
 catagoryID int primary key not null,
 catagoryName varchar (100) not null
)
go
Create table inventory 
(
productId  int references product(ProductID),
stockQuantity int 

)
go 

Create table Totalsales
(
Salesid int primary key,
saledate datetime,
TotalAmount money not null,
payment_mathod varchar (100) not null
)
go

Create table suppliers
(
SupplyersID int primary key,
supplyerName varchar (100) not null,
Phone varchar (11) ,
Email varchar (100) ,
[Address] varchar (100)
)
go 

/*
                             Session 03
					     Add check constraint
					   And default constraint.
--------------------------------------------------------------------------------
*/
create table Customer--i will make a store proc 
(
CustomerID int primary key,
First_Name varchar (100) not null,
last_Name varchar (100) not null,
Email varchar (120) not null,
Phone varchar (11) not null,
Address varchar (120)
)
go


create table product -- i will make a view later 
(
ProductID int primary key,
Product_name varchar (50) not null,
CatagoryId int References catagory(catagoryID),
SupplyerID int References suppliers(SupplyersID),
Price money not null ,
StockQunatity int null,
) 
go 
/*
                            Session 04
			 Create table with primary key and foreign key
--------------------------------------------------------------------------------
*/
create table Tranjection
(
TrajectionID CHAR(4) Check (TrajectionID like'T-[0-9] [0-9] [0-9]'),
Tranjection_Date datetime default Getdate(),
Tranjection_Type varchar (50) not null,
Amount money not null,
Comments varchar (50),--IT WILL ALTER LATER.
) 
go 
/*
                          session 05
				Alter and Modify table and colum
------------------------------------------------------------------------------------
*/
ALTER TABLE Tranjection
ALTER COLUMN Comments Text
go

/*
                      session 06 
			create view and alter view
-----------------------------------------------------------------------------------
*/
create view pview
as 
select *from product
go
---alter view 
alter view pview
as 
select productID,product_name,Price
from product
go
/* 
                                Session 07
		              Create a store procdure on a table
----------------------------------------------------------------------------------
*/
Create proc pcustomer
@CustomerID varchar (50)
as 
Begin
select
CustomerID, First_Name,last_Name,Email from Customer
where 
customerID=@CustomerID
end
go 
/*                          
                   Session 08
		       Make a Function (UDF)
-----------------------------------------------------------------------------------
*/
--first make a table 
create table orders
(
OrderId int primary key,
customerId int references Customer(CustomerID),
order_Date datetime default getdate(),
totalPrice  money ,
productID int references product(ProductID),
Quantity int 
)
go 

--function 

CREATE FUNCTION CalculateOrderTotal (@OrderID INT)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @TotalAmount DECIMAL(10, 2);

    SELECT @TotalAmount = SUM(Quantity * totalPrice)
    FROM Orders
    WHERE OrderID = @OrderID;

    RETURN @TotalAmount;
END;
------------------ ------------------THE END-------------------------------------






